import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import unittest,copy
from alarm_engine import state,DEFAULTS,validate_rules,evaluate
class TestAlarm(unittest.TestCase):
    def test_hysteresis(self):
        r=DEFAULTS['soil_moisture']
        self.assertEqual(state(24,r),'LOW'); self.assertEqual(state(25,r,'LOW'),'LOW'); self.assertEqual(state(28,r,'LOW'),'NORMAL')
    def test_high(self):
        r=DEFAULTS['soil_moisture']; self.assertEqual(state(66,r),'HIGH'); self.assertEqual(state(63,r,'HIGH'),'HIGH'); self.assertEqual(state(62,r,'HIGH'),'NORMAL'); self.assertEqual(state(20,r,'HIGH'),'LOW')
    def test_invalid(self):
        r=copy.deepcopy(DEFAULTS); r['water_ph']['min']=9
        with self.assertRaises(ValueError): validate_rules(r)
    def test_events(self):
        s,e=evaluate({'soil_moisture':20},DEFAULTS,{}); self.assertEqual(s['soil_moisture'],'LOW'); self.assertEqual(len(e),1)
        self.assertEqual(evaluate({'soil_moisture':20},DEFAULTS,s)[1],[])
    def test_disabled(self):
        r=dict(DEFAULTS['soil_moisture'],enabled=False); self.assertEqual(state(5,r,'LOW'),'DISABLED')
if __name__=='__main__': unittest.main()
