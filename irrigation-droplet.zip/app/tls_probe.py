import argparse, getpass, json, ssl, threading, uuid
import paho.mqtt.client as mqtt
p=argparse.ArgumentParser(); p.add_argument('hostname'); args=p.parse_args()
ready=threading.Event()
client=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id='tls-probe-'+uuid.uuid4().hex[:12])
client.username_pw_set('arduino001',getpass.getpass('Contraseña MQTT del Arduino: '))
client.tls_set_context(ssl.create_default_context())
def connected(c,u,f,rc,props):
    if rc==0: ready.set()
    else: print('Conexión rechazada:',rc,flush=True)
client.on_connect=connected
client.connect(args.hostname,8883,60); client.loop_start()
try:
    if not ready.wait(10): raise RuntimeError('No se confirmó conexión autenticada')
    d=dict(device_id='uno-r4-001',boot_id='tls-'+uuid.uuid4().hex,seq=0,soil_moisture=20,temperature=25,soil_ec=2.8,water_ph=6.7)
    info=client.publish('irrigation/uno-r4-001/telemetry',json.dumps(d),qos=1)
    info.wait_for_publish(timeout=10)
    if not info.is_published(): raise RuntimeError('No PUBACK')
    print('TLS y PUBACK correctos:', d,flush=True)
finally:
    client.disconnect(); client.loop_stop()
