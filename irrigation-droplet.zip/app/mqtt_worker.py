import os,json,logging,re
from datetime import datetime,timezone
import paho.mqtt.client as mqtt
from pymongo.errors import DuplicateKeyError
from alarm_engine import RANGES,number,evaluate
from database import db,rules_for
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')

def parse(topic,payload):
    p=topic.split('/')
    if len(p)!=3 or p[0]!='irrigation' or p[2]!='telemetry' or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',p[1]): raise ValueError('topic')
    if len(payload)>4096: raise ValueError('payload demasiado grande')
    d=json.loads(payload)
    if not isinstance(d,dict) or d.get('device_id')!=p[1]: raise ValueError('device_id')
    boot=d.get('boot_id'); seq=d.get('seq')
    if not isinstance(boot,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',boot) or type(seq) is not int or not 0<=seq<2**63: raise ValueError('identificador')
    vals={}
    for k,(lo,hi) in RANGES.items():
        v=number(d.get(k))
        if not lo<=v<=hi: raise ValueError(k)
        vals[k]=v
    return p[1],boot,seq,vals

def on_connect(c,u,f,rc,props):
    if rc==0:
        c.subscribe('irrigation/+/telemetry',qos=1)
        logging.info('Conectado; suscripción solicitada')
    else: logging.error('MQTT: %s',rc)

def on_subscribe(c,u,mid,reason_codes,properties):
    if reason_codes and all(not rc.is_failure for rc in reason_codes):
        logging.info('Suscripción MQTT confirmada')
    else: logging.error('Suscripción MQTT rechazada: %s',reason_codes)

def on_message(c,u,m):
    try:
        device,boot,seq,vals=parse(m.topic,m.payload)
    except (ValueError,TypeError,OverflowError):
        logging.warning('Mensaje inválido descartado')
        if m.qos: c.ack(m.mid,m.qos)
        return
    key=f'{device}:{boot}:{seq}'
    try:
        if not db.measurements.find_one({'_id':key},{'_id':1}):
            prev=db.measurements.find_one({'device_id':device},sort=[('timestamp',-1),('_id',-1)]) or {}
            rules=rules_for(device)
            states,events=evaluate(vals,rules,prev.get('states',{}))
            db.measurements.insert_one({'_id':key,'device_id':device,'boot_id':boot,'seq':seq,'timestamp':datetime.now(timezone.utc),**vals,'states':states,'events':events,'rules':rules})
            logging.info('Guardado %s %s',key,states)
    except DuplicateKeyError: pass
    except Exception:
        logging.exception('Fallo de persistencia; reiniciar sin ACK')
        # El proceso sale; Compose lo reinicia. Sesión MQTT persistente.
        os._exit(1)
    if m.qos: c.ack(m.mid,m.qos)

if __name__=='__main__':
    c=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,client_id='irrigation-worker',clean_session=False,manual_ack=True)
    c.username_pw_set(os.environ['MQTT_USER'],os.environ['MQTT_PASSWORD'])
    c.on_connect=on_connect; c.on_subscribe=on_subscribe; c.on_message=on_message
    c.reconnect_delay_set(1,30)
    c.connect_async('mosquitto',1883,60)
    c.loop_forever(retry_first_connection=True)
