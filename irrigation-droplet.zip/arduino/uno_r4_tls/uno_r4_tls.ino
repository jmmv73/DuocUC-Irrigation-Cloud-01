#include <WiFiS3.h>
#include <ArduinoMqttClient.h>
// Datos sintéticos: no conecta sensores ni bombas.
const char SSID[] = "REEMPLAZAR";
const char WIFI_PASSWORD[] = "REEMPLAZAR";
const char BROKER[] = "mqtt.ejemplo.cl"; // DNS real que coincide con certificado
const char MQTT_PASSWORD[] = "REEMPLAZAR";
const char BOOT_ID[] = "lab-001"; // Cambiar por un identificador nuevo en cada arranque de prueba
const char TOPIC[] = "irrigation/uno-r4-001/telemetry";
WiFiSSLClient wifi;
MqttClient mqtt(wifi);
unsigned long seq = 0, last = 0;
void setup(){
  Serial.begin(115200);
  mqtt.setId("uno-r4-001");
  mqtt.setUsernamePassword("arduino001", MQTT_PASSWORD);
}
void loop(){
  if(WiFi.status()!=WL_CONNECTED){
    WiFi.begin(SSID,WIFI_PASSWORD); delay(5000); return;
  }
  if(!mqtt.connected()){
    if(!mqtt.connect(BROKER,8883)){Serial.println(mqtt.connectError());delay(3000);return;}
  }
  mqtt.poll();
  if(millis()-last<30000UL) return;
  last=millis();
  String payload=String("{\"device_id\":\"uno-r4-001\",\"boot_id\":\"")+BOOT_ID+"\",\"seq\":"+String(seq)+",\"soil_moisture\":20.0,\"temperature\":25.0,\"soil_ec\":2.8,\"water_ph\":6.7}";
  mqtt.beginMessage(TOPIC, (unsigned long)payload.length(), false, 1);
  mqtt.print(payload);
  if(mqtt.endMessage()){Serial.println(payload);seq++;}
  else Serial.println("Publicación sin confirmar; verificar conexión");
}
