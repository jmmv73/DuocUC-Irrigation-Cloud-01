#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
# No ejecutar con sudo: .env debe pertenecer al operador.
if [[ -e .env ]]; then echo '.env ya existe; no se sobrescribe.'; exit 1; fi
umask 077
# Solo valores hexadecimales, compatibles con Compose y MQTT.
admin=$(openssl rand -hex 24)
app=$(openssl rand -hex 24)
worker=$(openssl rand -hex 24)
arduino=$(openssl rand -hex 24)
set -o noclobber
cat > .env <<END
APP_IMAGE=irrigation:1.0.0
MONGO_ADMIN=admin
MONGO_ADMIN_PASSWORD=$admin
APP_DB_USER=iotapp
APP_DB_PASSWORD=$app
MQTT_USER=worker
MQTT_PASSWORD=$worker
ARDUINO_MQTT_PASSWORD=$arduino
MQTT_BIND=127.0.0.1
MQTT_TLS=0
END
chmod 600 .env
echo 'Credenciales nuevas generadas; .env es privado.'
