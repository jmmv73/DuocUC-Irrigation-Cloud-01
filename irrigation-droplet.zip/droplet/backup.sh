#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Respaldo lógico de irrigation (no usuarios ni datos MQTT).
# Detenga otras fuentes antes; el broker puede encolar QoS 1.
umask 077
mkdir -p backups
file="backups/irrigation-$(date -u +%Y%m%dT%H%M%SZ).archive.gz"
sudo docker compose stop dashboard mqtt-worker
trap 'sudo docker compose start mqtt-worker dashboard' EXIT
sudo docker compose exec -T mongodb sh -c 'exec mongodump --username "$APP_DB_USER" --password "$APP_DB_PASSWORD" --authenticationDatabase irrigation --db irrigation --archive --gzip' > "$file.tmp"
mv "$file.tmp" "$file"
ls -lh "$file"
echo 'Transfiera este archivo fuera del Droplet. Guarde .env y TLS en un lugar seguro aparte.'
