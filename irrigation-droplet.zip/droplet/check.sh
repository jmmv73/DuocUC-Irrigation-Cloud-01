#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Ejecutar como operador, sin sudo (Docker se invoca mediante sudo).
sudo docker compose ps
curl -fsS http://127.0.0.1:8080/health; echo
# Esperar SUBACK real antes de enviar una muestra.
for i in $(seq 1 30); do
  if sudo docker compose logs mqtt-worker | grep -q 'Suscripción MQTT confirmada'; then break; fi
  sleep 2
done
sudo docker compose logs mqtt-worker | grep -q 'Suscripción MQTT confirmada'
boot="check-$(openssl rand -hex 8)"
sudo docker compose run --rm --no-deps simulator python simulator.py --once --boot "$boot"
for i in $(seq 1 20); do
  if curl -fsS http://127.0.0.1:8080/api/latest | python3 -c 'import json,sys; m=json.load(sys.stdin)["measurement"]; assert m and m["boot_id"]==sys.argv[1] and m["soil_moisture"]==20 and m["soil_ec"]==2.8' "$boot"; then echo 'OK: MQTT -> MongoDB -> API'; exit 0; fi
  sleep 2
done
echo 'Fallo de integración: revise logs. Detenga otras fuentes antes de repetir.' >&2
exit 1
