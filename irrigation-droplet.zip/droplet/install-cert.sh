#!/bin/bash
set -euo pipefail
# sudo bash droplet/install-cert.sh mqtt.ejemplo.cl
cd "$(dirname "$0")/.."
name=${1:?Indique nombre DNS real del certificado}
[[ "$name" =~ ^[a-zA-Z0-9.-]+$ ]] || exit 1
base=/etc/letsencrypt/live/$name
openssl x509 -in "$base/fullchain.pem" -noout -checkend 86400
install -d -m 700 certs
# El broker se ejecutará como usuario mosquitto dentro del contenedor.
gid=$(docker run --rm --entrypoint id eclipse-mosquitto:2 -g mosquitto)
install -m 644 -o root -g "$gid" "$base/fullchain.pem" certs/fullchain.pem
install -m 640 -o root -g "$gid" "$base/privkey.pem" certs/privkey.pem
chown root:"$gid" certs
chmod 750 certs
echo 'Certificado copiado. Recree o reinicie Mosquitto para cargarlo.'
