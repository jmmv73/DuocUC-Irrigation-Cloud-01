# Smart Irrigation · DigitalOcean
Guía HTML complementaria: `guia-iot-digitalocean.html`.

- Mosquitto, MongoDB, worker Python y Flask/Gunicorn: cuatro servicios, tres imágenes.
- Local (red aislada): copie `.env.example` a `.env`, `docker build -t irrigation:1.0.0 .`, `docker compose up -d --wait --wait-timeout 180`.
- Droplet nuevo Ubuntu 24.04: `sudo bash droplet/install-docker.sh`, `bash droplet/init-env.sh`, `sudo docker build -t irrigation:1.0.0 .`, `sudo docker compose up -d --wait --wait-timeout 180`, `bash droplet/check.sh`.
- Dashboard no autenticado, solo loopback 8080 y túnel SSH. MQTT 1883 loopback; TLS 8883 con `compose.tls.yaml` únicamente tras configurar certificados y firewall. Nunca exponga MongoDB.
- Verifique los pasos de la guía antes de conectar hardware. Los sketches son telemetría sintética, no drivers de sensores.
- No publique `.env`, certificados, archivos de respaldo, contraseñas o claves SSH.
- No ejecute `docker compose down -v` sobre datos que desea conservar.
- Pruebas unitarias: `python -m unittest discover -s tests` (Python instalado; no necesita dependencias externas).
- La guía documenta límites de las pruebas efectuadas y las pendientes de Docker/Arduino/DigitalOcean.
