#!/bin/sh
set -eu
# Ejecutado como root inicialmente; mosquitto baja privilegios al usuario mosquitto.
mkdir -p /mosquitto/data
chown mosquitto:mosquitto /mosquitto/data
mosquitto_passwd -b -c /tmp/passwords arduino001 "$ARDUINO_MQTT_PASSWORD"
mosquitto_passwd -b /tmp/passwords "$MQTT_USER" "$MQTT_PASSWORD"
chown mosquitto:mosquitto /tmp/passwords
chmod 600 /tmp/passwords
cp /config/mosquitto.conf /tmp/broker.conf
if [ "$MQTT_TLS" = 1 ]; then
  cat /config/tls.conf >> /tmp/broker.conf
fi
exec mosquitto -c /tmp/broker.conf
