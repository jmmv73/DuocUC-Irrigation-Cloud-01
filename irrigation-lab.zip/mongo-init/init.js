const appdb = db.getSiblingDB('irrigation');
appdb.createUser({user: process.env.APP_DB_USER, pwd: process.env.APP_DB_PASSWORD,
  roles: [{role: 'readWrite', db: 'irrigation'}]});
appdb.measurements.createIndex({device_id: 1, timestamp: -1});
