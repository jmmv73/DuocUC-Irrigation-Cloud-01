import argparse,os,json,random,time,uuid,threading
import paho.mqtt.client as mqtt
p=argparse.ArgumentParser(); p.add_argument('--once',action='store_true'); p.add_argument('--interval',type=float,default=5); p.add_argument('--boot',default=None); args=p.parse_args()
if args.interval<=0: p.error('interval must be positive')
boot=args.boot or uuid.uuid4().hex
ready=threading.Event()
c=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,client_id='sim-'+uuid.uuid4().hex[:12])
c.username_pw_set('arduino001',os.environ['ARDUINO_MQTT_PASSWORD'])
def connected(c,u,f,rc,props):
    if rc==0: ready.set()
    else: print('MQTT rechazado:',rc)
c.on_connect=connected
c.connect('mosquitto',1883,60); c.loop_start()
try:
    if not ready.wait(10): raise RuntimeError('Sin conexión MQTT')
    seq=0
    while True:
        vals=[20,25,2.8,6.7] if args.once else [round(random.uniform(a,b),2) for a,b in [(15,80),(10,40),(.2,4),(4,9)]]
        d=dict(device_id='uno-r4-001',boot_id=boot,seq=seq,**dict(zip(['soil_moisture','temperature','soil_ec','water_ph'],vals)))
        info=c.publish('irrigation/uno-r4-001/telemetry',json.dumps(d),qos=1)
        info.wait_for_publish(timeout=10)
        if not info.is_published(): raise RuntimeError('Sin PUBACK')
        print(d,flush=True)
        if args.once: break
        seq+=1; time.sleep(args.interval)
finally:
    c.disconnect(); c.loop_stop()
