import os
from pymongo import MongoClient
from alarm_engine import DEFAULTS
client = MongoClient('mongodb',27017,username=os.environ['APP_DB_USER'],password=os.environ['APP_DB_PASSWORD'],authSource='irrigation',tz_aware=True,serverSelectionTimeoutMS=5000)
db=client.irrigation

def rules_for(device):
    row=db.alarm_rules.find_one({'_id':device})
    return row['rules'] if row else DEFAULTS
