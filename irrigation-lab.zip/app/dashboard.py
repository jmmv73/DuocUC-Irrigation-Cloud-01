from datetime import datetime,timedelta,timezone
from flask import Flask,jsonify,request,send_from_directory
from pymongo.errors import PyMongoError
from database import db,rules_for
from alarm_engine import validate_rules
app=Flask(__name__)
app.config['MAX_CONTENT_LENGTH']=16384
DEVICE='uno-r4-001'

def serialize(row):
    if not row: return None
    return {**row,'timestamp':row['timestamp'].isoformat()}
@app.errorhandler(PyMongoError)
def database_error(e): return jsonify(error='Base de datos no disponible'),503
@app.get('/')
def index(): return send_from_directory('/app','index.html')
@app.get('/health')
def health():
    db.command('ping'); return jsonify(ok=True)
@app.get('/api/latest')
def latest():
    row=db.measurements.find_one({'device_id':DEVICE},sort=[('timestamp',-1),('_id',-1)])
    return jsonify(measurement=serialize(row),stale=not row or (datetime.now(timezone.utc)-row['timestamp']).total_seconds()>90)
@app.get('/api/history')
def history():
    try: hours=float(request.args.get('hours',24)); assert 0<hours<=168
    except (ValueError,AssertionError): return jsonify(error='hours debe estar entre 0 y 168'),400
    rows=list(db.measurements.find({'device_id':DEVICE,'timestamp':{'$gte':datetime.now(timezone.utc)-timedelta(hours=hours)}}, {'rules':0}).sort([('timestamp',-1),('_id',-1)]).limit(5001))
    return jsonify(rows=[serialize(r) for r in reversed(rows[:5000])],truncated=len(rows)>5000)
@app.get('/api/alarms/rules')
def get_rules(): return jsonify(rules_for(DEVICE))
@app.put('/api/alarms/rules')
def put_rules():
    if not request.is_json: return jsonify(error='JSON requerido'),415
    try: rules=validate_rules(request.get_json())
    except (ValueError,TypeError,OverflowError): return jsonify(error='Reglas inválidas. Revise límites e histéresis.'),400
    db.alarm_rules.replace_one({'_id':DEVICE},{'_id':DEVICE,'rules':rules},upsert=True)
    return jsonify(rules)
@app.get('/api/alarms/history')
def events():
    rows=db.measurements.find({'device_id':DEVICE,'events.0':{'$exists':True}},{'timestamp':1,'events':1}).sort([('timestamp',-1),('_id',-1)]).limit(100)
    return jsonify([{'timestamp':r['timestamp'].isoformat(),**e} for r in rows for e in r['events']])
