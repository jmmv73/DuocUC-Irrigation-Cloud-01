import math

DEFAULTS = {
    'soil_moisture': {'min': 25, 'max': 65, 'h': 3, 'enabled': True},
    'temperature': {'min': 15, 'max': 30, 'h': 1, 'enabled': True},
    'soil_ec': {'min': 0.5, 'max': 2.5, 'h': 0.1, 'enabled': True},
    'water_ph': {'min': 5.5, 'max': 7.5, 'h': 0.2, 'enabled': True},
}
RANGES = {'soil_moisture': (0,100), 'temperature': (-40,125), 'soil_ec': (0,100), 'water_ph': (0,14)}
DECISIONS = {
 'soil_moisture': ('Evaluar inicio de riego', 'Evaluar detención de riego'),
 'temperature': ('Revisar temperatura baja', 'Revisar estrés térmico'),
 'soil_ec': ('Revisar nutrientes y calibración', 'Revisar salinidad'),
 'water_ph': ('Revisar acidez', 'Revisar alcalinidad'),
}

def number(v):
    if isinstance(v, bool) or not isinstance(v, (int,float)) or not math.isfinite(v):
        raise ValueError('Se requiere número finito')
    return float(v)

def validate_rules(rules):
    if not isinstance(rules, dict) or set(rules) != set(DEFAULTS):
        raise ValueError('Se requieren cuatro reglas')
    result = {}
    for k, r in rules.items():
        if not isinstance(r,dict) or set(r) != {'min','max','h','enabled'} or not isinstance(r['enabled'],bool):
            raise ValueError('Regla inválida: '+k)
        lo, hi, h = (number(r[n]) for n in ('min','max','h'))
        a,b=RANGES[k]
        if not (a <= lo < hi <= b and 0 <= h <= (hi-lo)/2):
            raise ValueError('Límites o histéresis inválidos: '+k)
        result[k] = {'min':lo,'max':hi,'h':h,'enabled':r['enabled']}
    return result

def state(value, rule, previous='NORMAL'):
    if not rule['enabled']: return 'DISABLED'
    lo,hi,h=rule['min'],rule['max'],rule['h']
    if value < lo: return 'LOW'
    if value > hi: return 'HIGH'
    if previous == 'LOW' and value < lo+h: return 'LOW'
    if previous == 'HIGH' and value > hi-h: return 'HIGH'
    return 'NORMAL'

def evaluate(values, rules, previous):
    states, events = {}, []
    for k,v in values.items():
        before=previous.get(k,'NORMAL')
        after=state(v,rules[k],before)
        states[k]=after
        if after != before:
            decision = DECISIONS[k][0 if after=='LOW' else 1] if after in ('LOW','HIGH') else ('Recuperación del rango' if after=='NORMAL' else 'Alarma deshabilitada')
            events.append({'sensor':k,'from':before,'to':after,'value':v,'decision':decision})
    return states,events
