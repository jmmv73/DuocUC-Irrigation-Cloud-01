#!/bin/bash
set -euo pipefail
cd /opt/smart-irrigation
image=$(cat app-image.txt)
registry=${image%%/*}
region=$(cut -d. -f4 <<< "$registry")
aws ecr get-login-password --region "$region" | docker login --username AWS --password-stdin "$registry"
trap 'docker logout "$registry" >/dev/null 2>&1 || true' EXIT
docker pull "$image"
docker pull mongo:8.0
docker pull eclipse-mosquitto:2
