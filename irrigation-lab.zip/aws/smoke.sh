#!/bin/bash
set -euo pipefail
cd /opt/smart-irrigation
# Exclusivamente para una instancia de prueba desechable, NO producción.
if [ -e .env ]; then echo 'Existe .env; se cancela prueba destructiva'; exit 1; fi
trap 'docker compose down -v --remove-orphans; rm -f .env' EXIT
cp .env.example .env
sed -i "s|^APP_IMAGE=.*|APP_IMAGE=$(cat app-image.txt)|" .env
docker compose up -d --pull never --wait --wait-timeout 180
# Esperar la conexión del consumidor antes de publicar.
for i in $(seq 1 40); do
  if docker compose logs mqtt-worker | grep -q 'Conectado; suscripción'; then break; fi
  sleep 2
done
docker compose logs mqtt-worker | grep -q 'Conectado; suscripción'
sleep 3
docker compose run --rm --no-deps simulator python simulator.py --once --boot awstoe
for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:8080/api/latest | python3 -c 'import json,sys; m=json.load(sys.stdin)["measurement"]; assert m and m["boot_id"]=="awstoe" and m["states"]["soil_moisture"]=="LOW" and m["states"]["soil_ec"]=="HIGH"'; then echo 'SMOKE OK'; exit 0; fi
  sleep 2
done
exit 1
