#!/bin/bash
set -euo pipefail
cd /opt/smart-irrigation
mountpoint -q /srv/iot-data || { echo 'Falta montar EBS en /srv/iot-data'; exit 1; }
mkdir -p /srv/iot-data/{mongodb,mosquitto}
# No regenerar credenciales si ya existe una base inicializada.
if [ ! -f .env ]; then
  if [ -n "$(ls -A /srv/iot-data/mongodb)" ]; then echo 'Base existente: restaure .env original antes de continuar'; exit 1; fi
  umask 077
  {
    printf 'APP_IMAGE=%s\n' "$(cat app-image.txt)"
    printf 'MONGO_ADMIN=admin\nAPP_DB_USER=iotapp\nMQTT_USER=worker\nMQTT_BIND=127.0.0.1\nMQTT_TLS=0\nCOMPOSE_FILE=compose.yaml:compose.aws.yaml\n'
    for key in MONGO_ADMIN_PASSWORD APP_DB_PASSWORD MQTT_PASSWORD ARDUINO_MQTT_PASSWORD; do
      printf '%s=%s\n' "$key" "$(openssl rand -hex 24)"
    done
  } > .env
fi
chmod 600 .env
install -m 644 aws/irrigation.service /etc/systemd/system/irrigation.service
mkdir -p /etc/systemd/system/docker.service.d
printf "[Unit]\nRequiresMountsFor=/srv/iot-data\nConditionPathIsMountPoint=/srv/iot-data\n" > /etc/systemd/system/docker.service.d/iot-data.conf
systemctl daemon-reload
systemctl enable --now irrigation.service
