# Smart Irrigation IoT · Laboratorio

Guía: abrir `index.html` distribuido junto a este ZIP (o publicado en GitHub Pages).

Inicio local: copiar `.env.example` a `.env`, ejecutar `docker build -t irrigation:1.0.0 .`, `docker compose up -d --wait --wait-timeout 180`, abrir http://localhost:8080 y ejecutar `docker compose run --rm simulator python simulator.py --once`.

No publicar `.env`, claves o certificados. No abrir MQTT sin TLS a Internet. Las mediciones y umbrales son ilustrativos. Código de referencia, no certificado para producción. No se ha ejecutado Docker ni AWS durante la preparación de este material.
